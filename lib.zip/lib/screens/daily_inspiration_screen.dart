import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

const _kGreen = Color(0xFF10B981);
const _kGold = Color(0xFFEAB308);
const _kBg = Color(0xFF05080F);
const _kCard = Color(0xFF121B2B);

class DailyInspirationScreen extends StatelessWidget {
  const DailyInspirationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Gets the day of the month (1-31) to automatically rotate content daily offline!
    final dayOfMonth = DateTime.now().day;
    final contentIndex = (dayOfMonth - 1) % _dailyData.length;
    final todayData = _dailyData[contentIndex];

    return Scaffold(
      backgroundColor: _kBg,
      body: Stack(
        children: [
          // Background Glow
          Positioned(
            top: -100, left: -50, right: -50,
            child: Container(
              height: 350,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [_kGold.withValues(alpha: 0.15), Colors.transparent],
                ),
              ),
            ),
          ),
          SafeArea(
            child: CustomScrollView(
              slivers: [
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 20, 20, 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Daily Inspiration',
                            style: GoogleFonts.outfit(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
                        Text('A daily dose of Quran & Sunnah',
                            style: GoogleFonts.outfit(color: Colors.white38, fontSize: 13)),
                        const SizedBox(height: 24),
                        
                        // ── AYAH OF THE DAY ──
                        Row(
                          children: [
                            const Icon(Icons.menu_book_rounded, color: _kGold, size: 20),
                            const SizedBox(width: 8),
                            Text('Ayah of the Day', style: GoogleFonts.outfit(color: _kGold, fontSize: 14, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
                          ],
                        ),
                        const SizedBox(height: 12),
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            color: _kCard,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: _kGold.withValues(alpha: 0.3), width: 1.5),
                            boxShadow: [BoxShadow(color: _kGold.withValues(alpha: 0.05), blurRadius: 20, spreadRadius: 2)],
                          ),
                          child: Column(
                            children: [
                              Text(
                                todayData.arabicAyah,
                                textAlign: TextAlign.center,
                                textDirection: TextDirection.rtl,
                                style: TextStyle(color: Colors.white, fontSize: 24, height: 1.8, fontFamily: GoogleFonts.amiri().fontFamily),
                              ),
                              const Padding(
                                padding: EdgeInsets.symmetric(vertical: 16),
                                child: Divider(color: Colors.white10, height: 1),
                              ),
                              Text(
                                '"${todayData.translationAyah}"',
                                textAlign: TextAlign.center,
                                style: GoogleFonts.outfit(color: Colors.white70, fontSize: 15, height: 1.5, fontStyle: FontStyle.italic),
                              ),
                              const SizedBox(height: 12),
                              Text(
                                todayData.referenceAyah,
                                style: GoogleFonts.outfit(color: _kGold, fontSize: 12, fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 32),

                        // ── HADITH OF THE DAY ──
                        Row(
                          children: [
                            const Icon(Icons.chat_bubble_rounded, color: _kGreen, size: 18),
                            const SizedBox(width: 8),
                            Text('Hadith of the Day', style: GoogleFonts.outfit(color: _kGreen, fontSize: 14, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
                          ],
                        ),
                        const SizedBox(height: 12),
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            color: _kCard,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: _kGreen.withValues(alpha: 0.3), width: 1.5),
                            boxShadow: [BoxShadow(color: _kGreen.withValues(alpha: 0.05), blurRadius: 20, spreadRadius: 2)],
                          ),
                          child: Column(
                            children: [
                              Text(
                                '"${todayData.hadithText}"',
                                textAlign: TextAlign.center,
                                style: GoogleFonts.outfit(color: Colors.white70, fontSize: 15, height: 1.5),
                              ),
                              const SizedBox(height: 16),
                              Text(
                                todayData.referenceHadith,
                                style: GoogleFonts.outfit(color: _kGreen, fontSize: 12, fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 120), // Bottom padding for navbar
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// Simple hardcoded database ensures 100% offline reliability.
// Add up to 31 items here to cover a full month.
class _DailyContent {
  final String arabicAyah;
  final String translationAyah;
  final String referenceAyah;
  final String hadithText;
  final String referenceHadith;

  const _DailyContent(this.arabicAyah, this.translationAyah, this.referenceAyah, this.hadithText, this.referenceHadith);
}

const _dailyData = [
  _DailyContent(
    "فَٱذۡكُرُونِیٓ أَذۡكُرۡكُمۡ وَٱشۡكُرُوا۟ لِی وَلَا تَكۡفُرُونِ",
    "So remember Me; I will remember you. And be grateful to Me and do not deny Me.",
    "Surah Al-Baqarah 2:152",
    "The most beloved of deeds to Allah are those that are most consistent, even if it is small.",
    "Sahih al-Bukhari 6464"
  ),
  _DailyContent(
    "إِنَّ مَعَ ٱلۡعُسۡرِ یُسۡرًا",
    "Indeed, with hardship [will be] ease.",
    "Surah Ash-Sharh 94:6",
    "There is no disease that Allah has created, except that He also has created its treatment.",
    "Sahih al-Bukhari 5678"
  ),
  _DailyContent(
    "وَهُوَ مَعَكُمۡ أَیۡنَ مَا كُنتُمۡ",
    "And He is with you wherever you are.",
    "Surah Al-Hadid 57:4",
    "Whoever travels a path in search of knowledge, Allah will make easy for him a path to Paradise.",
    "Sahih Muslim 2699"
  ),
];