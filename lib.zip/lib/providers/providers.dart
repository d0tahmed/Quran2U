import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:quran_recitation/models/models.dart';
import 'package:quran_recitation/services/quran_api_service.dart';
import 'package:quran_recitation/services/audio_player_service.dart';
import 'package:quran_recitation/services/interleaved_audio_service.dart';
import 'package:quran_recitation/services/download_service.dart';
import 'package:quran_recitation/services/mushaf_api_service.dart'; // <-- PASTED SAFELY AT THE TOP
import 'package:adhan/adhan.dart';
import 'package:geolocator/geolocator.dart';

final quranApiServiceProvider = Provider((ref) => QuranApiService());

final audioPlayerServiceProvider = Provider((ref) {
  final service = AudioPlayerService();
  ref.onDispose(() => service.dispose());
  return service;
});

final interleavedAudioServiceProvider = Provider((ref) {
  final service = InterleavedAudioService();
  ref.onDispose(() => service.dispose());
  return service;
});

final downloadServiceProvider = Provider((ref) => DownloadService());

final tarjumahModeProvider = StateProvider<bool>((ref) => false);

final currentAyahNumberProvider = StreamProvider<int?>((ref) async* {
  final svc = ref.watch(interleavedAudioServiceProvider);
  yield* svc.currentAyahStream;
});

final isUrduSegmentProvider = StreamProvider<bool>((ref) async* {
  final svc = ref.watch(interleavedAudioServiceProvider);
  yield* svc.isUrduSegmentStream;
});

final surahsProvider = FutureProvider<List<Surah>>((ref) async {
  final quranApi = ref.watch(quranApiServiceProvider);
  return quranApi.fetchAllSurahs();
});

final selectedTranslationProvider = StateProvider<int>((ref) => 0);

final surahAyahsProvider = FutureProvider.family<List<Ayah>, (int, int)>((ref, params) async {
  final (surahNumber, translationId) = params;
  final apiService = ref.watch(quranApiServiceProvider);
  final data = await apiService.fetchSurahWithAyahs(surahNumber, translationId: translationId);
  return data['ayahs'] ?? [];
});

final imamsProvider = Provider<List<Imam>>((ref) {
  return const [
    Imam(id: 1, name: 'Sheikh Abdul Rahman As-Sudais', identifier: 'https://server11.mp3quran.net/sds', country: 'Saudi Arabia'),
    Imam(id: 2, name: 'Sheikh Mishary Rashid Alafasy', identifier: 'https://server8.mp3quran.net/afs', country: 'Kuwait'),
    Imam(id: 3, name: 'Sheikh Yasser Ad-Dusari', identifier: 'https://server11.mp3quran.net/yasser', country: 'Saudi Arabia'),
    Imam(id: 4, name: 'Sheikh Mahir Al-Muaqily', identifier: 'https://server12.mp3quran.net/maher', country: 'Saudi Arabia'),
    Imam(id: 5, name: 'Sheikh Saud As-Shuraim', identifier: 'https://server7.mp3quran.net/shur', country: 'Saudi Arabia'),
  ];
});

final selectedImamProvider = StateProvider<Imam?>((ref) {
  final imams = ref.watch(imamsProvider);
  return imams.isNotEmpty ? imams.first : null;
});

final audioUrlProvider = Provider.family<String, (int, int)>((ref, params) {
  final (surahNumber, imamId) = params;
  final imams = ref.watch(imamsProvider);

  final selectedImam = imams.firstWhere(
    (imam) => imam.id == imamId,
    orElse: () => imams.isNotEmpty
        ? imams[0]
        : const Imam(id: 1, name: 'Default', identifier: 'https://server11.mp3quran.net/sds', country: ''),
  );
  final paddedSurah = surahNumber.toString().padLeft(3, '0');
  return '${selectedImam.identifier}/$paddedSurah.mp3';
});

final currentSurahProvider = StateProvider<int?>((ref) => null);

final playbackStateProvider = StreamProvider<PlaybackState?>((ref) async* {
  final audioPlayer = ref.watch(audioPlayerServiceProvider);
  final selectedSurah = ref.watch(currentSurahProvider);

  yield* audioPlayer.playerStateStream.asyncMap((_) {
    return Future.value(audioPlayer.getCurrentState(selectedSurah ?? 1));
  });
});

final bookmarksProvider = StateProvider<List<Bookmark>>((ref) => []);

final positionProvider = StreamProvider<Duration>((ref) async* {
  final tarjumahMode = ref.watch(tarjumahModeProvider);
  if (tarjumahMode) {
    final svc = ref.watch(interleavedAudioServiceProvider);
    yield* svc.positionStream;
  } else {
    final audioPlayer = ref.watch(audioPlayerServiceProvider);
    yield* audioPlayer.positionStream;
  }
});

final durationProvider = StreamProvider<Duration?>((ref) async* {
  final tarjumahMode = ref.watch(tarjumahModeProvider);
  if (tarjumahMode) {
    final svc = ref.watch(interleavedAudioServiceProvider);
    yield* svc.durationStream;
  } else {
    final audioPlayer = ref.watch(audioPlayerServiceProvider);
    yield* audioPlayer.durationStream;
  }
});

// ============================================================================
// DOWNLOAD & BULK DOWNLOAD PROVIDERS
// ============================================================================
final downloadedSurahsProvider = FutureProvider<List<Map<String, dynamic>>>((ref) async {
  final downloadService = ref.watch(downloadServiceProvider);
  return downloadService.getDownloadedSurahs();
});

class BulkDownloadState {
  final bool isDownloading;
  final double progress;
  final double overallProgress;
  final int currentSurah;
  final String status;

  BulkDownloadState({
    this.isDownloading = false,
    this.progress = 0.0,
    this.overallProgress = 0.0,
    this.currentSurah = 0,
    this.status = '',
  });

  BulkDownloadState copyWith({
    bool? isDownloading,
    double? progress,
    double? overallProgress,
    int? currentSurah,
    String? status,
  }) {
    return BulkDownloadState(
      isDownloading: isDownloading ?? this.isDownloading,
      progress: progress ?? this.progress,
      overallProgress: overallProgress ?? this.overallProgress,
      currentSurah: currentSurah ?? this.currentSurah,
      status: status ?? this.status,
    );
  }
}

class BulkDownloadNotifier extends StateNotifier<BulkDownloadState> {
  BulkDownloadNotifier() : super(BulkDownloadState());

  void start({int? imamId, String? imamIdentifier, bool? withTarjumah}) {
    state = state.copyWith(isDownloading: true, status: 'Initializing...', overallProgress: 0.0);
  }

  void cancel() {
    state = BulkDownloadState(); 
  }
}

final bulkDownloadProvider = StateNotifierProvider<BulkDownloadNotifier, BulkDownloadState>((ref) {
  return BulkDownloadNotifier();
});

// ============================================================================
// NAMAZ & QIBLA PROVIDERS (100% Offline)
// ============================================================================
final locationProvider = FutureProvider<Coordinates>((ref) async {
  final fallback = Coordinates(24.8607, 67.0011); // Fallback to Karachi
  
  try {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) return fallback;

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) return fallback;
    }
    if (permission == LocationPermission.deniedForever) return fallback;

    Position pos = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.low);
    return Coordinates(pos.latitude, pos.longitude);
  } catch (e) {
    return fallback;
  }
});

final prayerTimesProvider = FutureProvider<PrayerTimes>((ref) async {
  final coords = await ref.watch(locationProvider.future);
  final params = CalculationMethod.karachi.getParameters();
  params.madhab = Madhab.hanafi;
  return PrayerTimes.today(coords, params);
});

// ============================================================================
// MUSHAF (READING MODE) PROVIDERS
// ============================================================================

final mushafApiServiceProvider = Provider((ref) => MushafApiService());

// Provider for Uthmani & Indo-Pak Text Only
final mushafPageProvider = FutureProvider.family<String, (int, String)>((ref, params) async {
  final (page, script) = params;
  final service = ref.watch(mushafApiServiceProvider);
  return service.getPageText(page, script);
});